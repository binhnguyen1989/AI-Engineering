using MediatR;

namespace AiOpsService.McpServer.Contracts.Claims;

/// <summary>
/// Stand-ins for ClaimsService.Application. Mirrors the propose/confirm two-step shape used for
/// any tool with real side effects — same "propose, then commit" instinct as the Outbox pattern.
/// </summary>
public sealed record ProposePayoutCommand(string ClaimId, decimal Amount, string Justification)
    : IRequest<PendingActionResult>;

public sealed record ConfirmActionCommand(string ConfirmationToken) : IRequest<ConfirmActionResult>;

public sealed record PendingActionResult(string ConfirmationToken, string ActionType, string Summary, DateTimeOffset ExpiresAtUtc);

public sealed record ConfirmActionResult(bool Success, string Message);

public sealed class ClaimHandlers :
    IRequestHandler<ProposePayoutCommand, PendingActionResult>,
    IRequestHandler<ConfirmActionCommand, ConfirmActionResult>
{
    // Real implementation: persist pending actions in Postgres or Redis with a TTL, not in-memory —
    // this dictionary exists only to make the sample runnable and single-process.
    private static readonly Dictionary<string, (string ClaimId, decimal Amount)> PendingPayouts = new();

    public Task<PendingActionResult> Handle(ProposePayoutCommand request, CancellationToken ct)
    {
        var token = Guid.NewGuid().ToString("N")[..12];
        PendingPayouts[token] = (request.ClaimId, request.Amount);

        return Task.FromResult(new PendingActionResult(
            token,
            "ClaimPayout",
            $"Payout of {request.Amount:C} for claim {request.ClaimId}. Justification: {request.Justification}",
            DateTimeOffset.UtcNow.AddMinutes(15)));
    }

    public Task<ConfirmActionResult> Handle(ConfirmActionCommand request, CancellationToken ct)
    {
        if (!PendingPayouts.TryGetValue(request.ConfirmationToken, out var action))
            return Task.FromResult(new ConfirmActionResult(false, "Unknown or expired confirmation token."));

        PendingPayouts.Remove(request.ConfirmationToken);
        // Real implementation: publish PayoutApprovedEvent through the Outbox here.
        return Task.FromResult(new ConfirmActionResult(true, $"Payout of {action.Amount:C} for {action.ClaimId} confirmed and queued."));
    }
}

using MediatR;

namespace AiOpsService.McpServer.Contracts.Orders;

/// <summary>
/// Stand-in for OrderService.Application.Queries.GetOrderStatusQuery.
/// Delete this file and reference the real one once wired into KafkaDotnet.
/// </summary>
public sealed record GetOrderStatusQuery(string OrderId) : IRequest<OrderStatusResult>;

public sealed record OrderStatusResult(
    string OrderId,
    string Status,
    DateTimeOffset LastUpdatedUtc,
    string? CarrierTrackingNumber);

public sealed class GetOrderStatusHandler : IRequestHandler<GetOrderStatusQuery, OrderStatusResult>
{
    // Sample fixed dataset so the server is runnable standalone. Replace with the real
    // EF Core-backed handler from OrderService.Application when wiring this into KafkaDotnet.
    private static readonly Dictionary<string, OrderStatusResult> Orders = new()
    {
        ["ORD-12345"] = new("ORD-12345", "Shipped", DateTimeOffset.UtcNow.AddHours(-6), "1Z999AA10123456784"),
        ["ORD-67890"] = new("ORD-67890", "Processing", DateTimeOffset.UtcNow.AddMinutes(-40), null)
    };

    public Task<OrderStatusResult> Handle(GetOrderStatusQuery request, CancellationToken ct)
    {
        if (!Orders.TryGetValue(request.OrderId, out var result))
            throw new KeyNotFoundException($"No order found with ID '{request.OrderId}'.");

        return Task.FromResult(result);
    }
}

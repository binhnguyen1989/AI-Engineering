using MediatR;

namespace AiOpsService.McpServer.Contracts.Inventory;

/// <summary>
/// Stand-ins for InventoryService.Application. Replace with real project references when wiring
/// into KafkaDotnet — these exist only so this MCP server compiles and runs standalone.
/// </summary>
public sealed record GetInventoryLevelQuery(string Sku) : IRequest<InventoryLevelResult>;

public sealed record InventoryLevelResult(string Sku, int OnHand, int Reserved, int Available);

public sealed record ReserveInventoryCommand(string OrderId, string Sku, int Quantity)
    : IRequest<ReservationResult>;

public sealed record GetReservationQuery(string OrderId, string Sku) : IRequest<ReservationResult?>;

public sealed record ReservationResult(string ReservationId, string OrderId, string Sku, int Quantity, bool WasIdempotentReplay);

public sealed class InventoryHandlers :
    IRequestHandler<GetInventoryLevelQuery, InventoryLevelResult>,
    IRequestHandler<ReserveInventoryCommand, ReservationResult>,
    IRequestHandler<GetReservationQuery, ReservationResult?>
{
    private static readonly Dictionary<string, int> OnHand = new() { ["SKU-001"] = 500, ["SKU-002"] = 12 };
    private static readonly Dictionary<string, int> ReservedTotals = new();

    // Idempotency store keyed by (orderId, sku) — same discipline as the Kafka consumer
    // idempotency pattern elsewhere in KafkaDotnet. A retrying or looping agent must not
    // double-reserve stock.
    private static readonly Dictionary<(string OrderId, string Sku), ReservationResult> Reservations = new();

    public Task<InventoryLevelResult> Handle(GetInventoryLevelQuery request, CancellationToken ct)
    {
        var onHand = OnHand.GetValueOrDefault(request.Sku, 0);
        var reserved = ReservedTotals.GetValueOrDefault(request.Sku, 0);
        return Task.FromResult(new InventoryLevelResult(request.Sku, onHand, reserved, onHand - reserved));
    }

    public Task<ReservationResult> Handle(ReserveInventoryCommand request, CancellationToken ct)
    {
        var key = (request.OrderId, request.Sku);
        if (Reservations.TryGetValue(key, out var existing))
            return Task.FromResult(existing with { WasIdempotentReplay = true });

        var available = OnHand.GetValueOrDefault(request.Sku, 0) - ReservedTotals.GetValueOrDefault(request.Sku, 0);
        if (available < request.Quantity)
            throw new InvalidOperationException(
                $"Insufficient inventory for {request.Sku}: requested {request.Quantity}, available {available}.");

        ReservedTotals[request.Sku] = ReservedTotals.GetValueOrDefault(request.Sku, 0) + request.Quantity;
        var result = new ReservationResult(Guid.NewGuid().ToString(), request.OrderId, request.Sku, request.Quantity, false);
        Reservations[key] = result;
        return Task.FromResult(result);
    }

    public Task<ReservationResult?> Handle(GetReservationQuery request, CancellationToken ct)
        => Task.FromResult(Reservations.GetValueOrDefault((request.OrderId, request.Sku)));
}

using System.ComponentModel;
using System.Text.Json;
using AiOpsService.McpServer.Contracts.Inventory;
using AiOpsService.McpServer.Resilience;
using MediatR;
using ModelContextProtocol.Server;

namespace AiOpsService.McpServer.Tools;

/// <summary>
/// Write tool that IS safe for the agent to call more than once for the same order/SKU pair —
/// idempotency is enforced at the handler level (see InventoryContracts.cs), so a retrying or
/// looping agent gets back the original reservation instead of double-reserving stock.
/// Distinct from the confirm-gated tools in ConfirmGatedTools.cs, which need a human step first
/// because their side effect (money movement) isn't safely idempotent-by-key alone.
/// </summary>
[McpServerToolType]
public sealed class InventoryWriteTools(IMediator mediator, ILogger<InventoryWriteTools> logger)
{
    [McpServerTool, Description(
        "Reserve inventory for an order. Safe to call more than once with the same orderId and " +
        "sku — returns the existing reservation instead of creating a duplicate. Fails if " +
        "available stock is less than the requested quantity.")]
    public Task<string> ReserveInventory(
        [Description("The order ID this reservation is for")] string orderId,
        [Description("The SKU to reserve")] string sku,
        [Description("Quantity to reserve")] int quantity,
        CancellationToken ct)
    {
        return ToolExecutionGuard.ExecuteAsync(async () =>
        {
            var result = await mediator.Send(new ReserveInventoryCommand(orderId, sku, quantity), ct);
            return JsonSerializer.Serialize(new
            {
                success = true,
                result.ReservationId,
                result.Quantity,
                idempotentReplay = result.WasIdempotentReplay
            });
        }, logger, nameof(ReserveInventory));
    }
}

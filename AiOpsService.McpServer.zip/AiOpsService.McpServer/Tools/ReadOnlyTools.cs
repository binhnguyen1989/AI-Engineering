using System.ComponentModel;
using System.Text.Json;
using AiOpsService.McpServer.Contracts.Inventory;
using AiOpsService.McpServer.Contracts.Orders;
using MediatR;
using ModelContextProtocol.Server;

namespace AiOpsService.McpServer.Tools;

/// <summary>
/// Read-only tools. No confirmation step needed — safe for the agent to call freely, any
/// number of times, in any order.
/// </summary>
[McpServerToolType]
public sealed class OrderTools(IMediator mediator, ILogger<OrderTools> logger)
{
    [McpServerTool, Description(
        "Get the current status of an order by its ID. Returns status, last-updated time, " +
        "and carrier tracking number if shipped. Use this before answering any question about " +
        "where an order is or whether it has shipped.")]
    public async Task<string> GetOrderStatus(
        [Description("The order ID, formatted like ORD-12345")] string orderId,
        CancellationToken ct)
    {
        try
        {
            var result = await mediator.Send(new GetOrderStatusQuery(orderId), ct);
            return JsonSerializer.Serialize(result);
        }
        catch (KeyNotFoundException ex)
        {
            logger.LogInformation("GetOrderStatus miss for {OrderId}", orderId);
            // Return a structured miss, not an exception — lets the model react sensibly
            // (e.g., "ask the user to double check the order ID") instead of surfacing a raw error.
            return JsonSerializer.Serialize(new { found = false, message = ex.Message });
        }
    }
}

[McpServerToolType]
public sealed class InventoryTools(IMediator mediator)
{
    [McpServerTool, Description(
        "Get current inventory levels for a SKU: on-hand quantity, reserved quantity, and " +
        "available-to-promise (on-hand minus reserved). Use before confirming any order can be fulfilled.")]
    public async Task<string> GetInventoryLevel(
        [Description("The SKU code, e.g. SKU-001")] string sku,
        CancellationToken ct)
    {
        var result = await mediator.Send(new GetInventoryLevelQuery(sku), ct);
        return JsonSerializer.Serialize(result);
    }
}

using System.ComponentModel;
using System.Text.Json;
using AiOpsService.McpServer.Auth;
using AiOpsService.McpServer.Contracts.Claims;
using AiOpsService.McpServer.Resilience;
using MediatR;
using ModelContextProtocol.Server;

namespace AiOpsService.McpServer.Tools;

/// <summary>
/// Two-step propose/confirm tools for side effects that must not execute purely on the model's
/// say-so — money movement, deletes, anything not cleanly idempotent-by-key. Mirrors the
/// Outbox pattern's "propose, then commit" shape.
///
/// ProposePayout never moves money; it only returns a confirmation token. ConfirmPendingAction
/// is the only tool that actually executes the effect, and in a real deployment should be gated
/// behind an explicit UI approval step or a second, more tightly scoped auth check — not just
/// "the model decided to call it," which defeats the purpose of the gate.
/// </summary>
[McpServerToolType]
public sealed class ClaimPayoutTools(IMediator mediator, ILogger<ClaimPayoutTools> logger, ToolScopeGuard scopeGuard)
{
    [McpServerTool, Description(
        "Propose a claim payout. Does NOT execute the payout — returns a confirmation token that " +
        "must be passed to ConfirmPendingAction by a human reviewer before the payout occurs. " +
        "Always call this instead of trying to pay out a claim directly.")]
    public Task<string> ProposePayout(
        [Description("The claim ID")] string claimId,
        [Description("Proposed payout amount in USD")] decimal amount,
        [Description("Brief justification for this amount")] string justification,
        CancellationToken ct)
    {
        return ToolExecutionGuard.ExecuteAsync(async () =>
        {
            var result = await mediator.Send(new ProposePayoutCommand(claimId, amount, justification), ct);
            return JsonSerializer.Serialize(new
            {
                success = true,
                result.ConfirmationToken,
                result.Summary,
                result.ExpiresAtUtc,
                note = "This action is NOT executed yet. A human must confirm via ConfirmPendingAction."
            });
        }, logger, nameof(ProposePayout));
    }

    [McpServerTool, Description(
        "Execute a previously proposed action using its confirmation token. This is the only " +
        "tool that actually performs a side effect for propose/confirm-gated actions like payouts. " +
        "In production this should require an out-of-band human approval, not just a model decision.")]
    public Task<string> ConfirmPendingAction(
        [Description("The confirmation token returned by a propose-style tool")] string confirmationToken,
        CancellationToken ct)
    {
        return ToolExecutionGuard.ExecuteAsync(async () =>
        {
            // Narrowest scope in the system — only callers explicitly granted confirm rights
            // (a human-approval flow, not the agent itself) should hold this scope.
            scopeGuard.RequireScope("aiops:tools:confirm");

            var result = await mediator.Send(new ConfirmActionCommand(confirmationToken), ct);
            return JsonSerializer.Serialize(new { result.Success, result.Message });
        }, logger, nameof(ConfirmPendingAction));
    }
}

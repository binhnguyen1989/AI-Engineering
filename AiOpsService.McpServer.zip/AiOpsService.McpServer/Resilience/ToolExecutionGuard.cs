using System.Text.Json;

namespace AiOpsService.McpServer.Resilience;

/// <summary>
/// Wraps tool execution the same way Shared.Caching's SafeExecuteAsync wraps Redis calls:
/// catch the known failure modes, return a structured, model-digestible error instead of an
/// unhandled exception, and never let a single tool failure crash the whole agent session.
///
/// This does NOT replace idempotency at the handler level (see InventoryContracts.cs) — it
/// guards against transient/infra failures, not against double-invocation from agent retries.
/// </summary>
public static class ToolExecutionGuard
{
    public static async Task<string> ExecuteAsync(
        Func<Task<string>> operation,
        ILogger logger,
        string toolName)
    {
        try
        {
            return await operation();
        }
        catch (InvalidOperationException ex)
        {
            // Domain-rule violation (e.g., insufficient inventory) — expected, model-recoverable.
            logger.LogInformation(ex, "Tool {ToolName} domain rule violation", toolName);
            return JsonSerializer.Serialize(new { success = false, error = ex.Message });
        }
        catch (TimeoutException ex)
        {
            logger.LogWarning(ex, "Tool {ToolName} timed out", toolName);
            return JsonSerializer.Serialize(new
            {
                success = false,
                error = "The downstream service timed out. This may be transient — consider retrying once."
            });
        }
        catch (Exception ex)
        {
            // Unexpected — log with full detail, return a generic message to the model.
            // Never leak stack traces or internal exception detail into the tool result;
            // that text becomes untrusted input the model reasons over next.
            logger.LogError(ex, "Tool {ToolName} failed unexpectedly", toolName);
            return JsonSerializer.Serialize(new
            {
                success = false,
                error = "An internal error occurred processing this request."
            });
        }
    }
}

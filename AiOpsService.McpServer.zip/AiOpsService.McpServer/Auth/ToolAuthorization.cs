using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;

namespace AiOpsService.McpServer.Auth;

/// <summary>
/// Auth setup for the MCP HTTP endpoint. In the real KafkaDotnet solution, replace this with a
/// project reference to Shared.Auth and reuse its Auth0 JWT validation + Redis-backed revocation
/// (FailClosed mode) directly instead of re-implementing JWT bearer config here — this file
/// exists to keep the sample self-contained and buildable on its own.
/// </summary>
public static class ToolAuthorization
{
    public const string ReadOnlyPolicy = "AiOpsTools.ReadOnly";
    public const string WritePolicy = "AiOpsTools.Write";
    public const string ConfirmPolicy = "AiOpsTools.Confirm"; // narrowest scope — only for ConfirmPendingAction

    public static IServiceCollection AddAiOpsToolAuth(this IServiceCollection services, IConfiguration config)
    {
        services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.Authority = config["Auth0:Authority"]; // e.g. https://your-tenant.auth0.com/
                options.Audience = config["Auth0:Audience"];   // e.g. https://aiops.kafkadotnet.internal
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.FromSeconds(30)
                };
                // Real implementation: plug in Shared.Auth's token revocation check here
                // (Redis-backed, FailClosed) via options.Events.OnTokenValidated.
            });

        services.AddAuthorizationBuilder()
            .AddPolicy(ReadOnlyPolicy, p => p.RequireClaim("scope", "aiops:tools:read"))
            .AddPolicy(WritePolicy, p => p.RequireClaim("scope", "aiops:tools:write"))
            .AddPolicy(ConfirmPolicy, p => p.RequireClaim("scope", "aiops:tools:confirm"));

        return services;
    }
}

/// <summary>
/// Per-tool scope check for use inside tool method bodies, since MCP tools are C# methods
/// rather than individually routable HTTP endpoints — endpoint-level [Authorize] on the MCP
/// route gets you "caller has a valid token," this gets you "caller may invoke THIS tool."
/// </summary>
public sealed class ToolScopeGuard(IHttpContextAccessor httpContextAccessor)
{
    public void RequireScope(string requiredScope)
    {
        var user = httpContextAccessor.HttpContext?.User
            ?? throw new UnauthorizedAccessException("No authenticated context available for tool call.");

        var hasScope = user.Claims.Any(c => c.Type == "scope" && c.Value.Split(' ').Contains(requiredScope));
        if (!hasScope)
            throw new UnauthorizedAccessException($"Missing required scope '{requiredScope}' for this tool.");
    }
}

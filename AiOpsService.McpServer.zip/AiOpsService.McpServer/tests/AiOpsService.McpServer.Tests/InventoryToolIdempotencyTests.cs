using System.Text.Json;
using AiOpsService.McpServer.Contracts.Inventory;
using AiOpsService.McpServer.Tools;
using FluentAssertions;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;

namespace AiOpsService.McpServer.Tests;

/// <summary>
/// The single most important property for any agent-callable write tool: calling it twice
/// with the same key must not double-execute the side effect. This is the direct .NET analog
/// to testing Kafka consumer idempotency — the "duplicate" trigger here is an agent retry or
/// reasoning loop instead of at-least-once delivery, but the assertion is the same shape.
/// </summary>
public sealed class InventoryToolIdempotencyTests
{
    private static IMediator BuildMediator()
    {
        var services = new ServiceCollection();
        services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(InventoryHandlers).Assembly));
        return services.BuildServiceProvider().GetRequiredService<IMediator>();
    }

    [Fact]
    public async Task ReserveInventory_CalledTwiceWithSameKey_DoesNotDoubleReserve()
    {
        var mediator = BuildMediator();
        var tool = new InventoryWriteTools(mediator, NullLogger<InventoryWriteTools>.Instance);

        var first = await tool.ReserveInventory("ORD-TEST-1", "SKU-001", 5, CancellationToken.None);
        var second = await tool.ReserveInventory("ORD-TEST-1", "SKU-001", 5, CancellationToken.None);

        using var firstDoc = JsonDocument.Parse(first);
        using var secondDoc = JsonDocument.Parse(second);

        var firstReservationId = firstDoc.RootElement.GetProperty("ReservationId").GetString();
        var secondReservationId = secondDoc.RootElement.GetProperty("ReservationId").GetString();

        secondReservationId.Should().Be(firstReservationId,
            "a retried or looped agent call must return the original reservation, not create a new one");
        secondDoc.RootElement.GetProperty("idempotentReplay").GetBoolean().Should().BeTrue();
    }

    [Fact]
    public async Task ReserveInventory_InsufficientStock_ReturnsStructuredErrorNotException()
    {
        var mediator = BuildMediator();
        var tool = new InventoryWriteTools(mediator, NullLogger<InventoryWriteTools>.Instance);

        var result = await tool.ReserveInventory("ORD-TEST-2", "SKU-002", 9_999, CancellationToken.None);

        using var doc = JsonDocument.Parse(result);
        doc.RootElement.GetProperty("success").GetBoolean().Should().BeFalse(
            "the model needs a structured, digestible error — not an unhandled exception propagating out of the tool call");
    }
}

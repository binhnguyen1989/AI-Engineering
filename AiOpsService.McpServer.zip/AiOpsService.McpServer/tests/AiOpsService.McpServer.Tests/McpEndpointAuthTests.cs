using System.Net;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

namespace AiOpsService.McpServer.Tests;

/// <summary>
/// The MCP endpoint must never be reachable without a valid token — a server exposing
/// write-capable tools with no auth gate is the single riskiest misconfiguration covered
/// in the MCP security guidance. This test exists to catch that regression, not to
/// exercise auth logic itself (that's Auth0/JWT middleware, already well-tested upstream).
/// </summary>
public sealed class McpEndpointAuthTests(WebApplicationFactory<Program> factory) : IClassFixture<WebApplicationFactory<Program>>
{
    [Fact]
    public async Task McpEndpoint_WithoutAuthToken_Returns401()
    {
        var client = factory.CreateClient();

        var response = await client.PostAsync("/mcp", new StringContent("{}"));

        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }

    [Fact]
    public async Task HealthLive_IsReachableWithoutAuth()
    {
        var client = factory.CreateClient();

        var response = await client.GetAsync("/health/live");

        response.StatusCode.Should().Be(HttpStatusCode.OK);
    }
}

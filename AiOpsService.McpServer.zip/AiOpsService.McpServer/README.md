# AiOpsService.McpServer

A complete, runnable MCP server exposing KafkaDotnet-style tools over Streamable HTTP, with the
production concerns from the Tier 2–3 roadmap already built in: auth, per-tool scope enforcement,
idempotent writes, propose/confirm gating for money-moving actions, resilience wrapping, structured
logging, and Prometheus metrics.

## What's in here

```
Program.cs                     Host wiring: MediatR, auth, MCP server, metrics, health checks
Tools/
  ReadOnlyTools.cs              GetOrderStatus, GetInventoryLevel — safe to call freely
  IdempotentWriteTools.cs       ReserveInventory — safe to retry, enforced idempotent by (orderId, sku)
  ConfirmGatedTools.cs          ProposePayout / ConfirmPendingAction — two-step, narrowest scope
Auth/ToolAuthorization.cs      JWT bearer + per-tool scope policies (read/write/confirm)
Resilience/ToolExecutionGuard.cs  Catches known failure modes, returns structured errors to the model
Contracts/                     Self-contained in-memory MediatR handlers — SEE "Wiring in" BELOW
k8s/                            Deployment + Service manifests (Prometheus scrape annotations, HPA)
Dockerfile                      Multi-stage build, non-root runtime user
tests/                          Idempotency test + auth-gate integration test
```

## Running it locally

```bash
dotnet restore
dotnet run
```

The server listens on `http://localhost:8080/mcp` (Streamable HTTP transport). `/health/live` and
`/health/ready` are unauthenticated. Everything under `/mcp` requires a valid JWT with at least the
`aiops:tools:read` scope; `ConfirmPendingAction` additionally requires `aiops:tools:confirm`.

For local dev without a real Auth0 tenant, either point `Auth0:Authority`/`Auth0:Audience` at a
throwaway tenant, or temporarily relax `ToolAuthorization.AddAiOpsToolAuth` to skip validation —
don't ship that relaxation past your own machine.

Connect from Claude Desktop or any MCP host by adding an HTTP server pointing at
`http://localhost:8080/mcp` with a bearer token in the request.

## Wiring this into the real KafkaDotnet solution

Everything under `Contracts/` is a **stand-in**, not the real domain — in-memory dictionaries so
this project builds and runs standalone. To wire it in for real:

1. Delete `Contracts/`.
2. Add project references to `OrderService.Application`, `InventoryService.Application`, and
   `ClaimsService.Application` (the `.csproj` has the exact reference lines commented in).
3. Update the `using` statements in `Tools/*.cs` to point at the real query/command types
   (`GetOrderStatusQuery`, `ReserveInventoryCommand`, etc.) — the tool method bodies don't change,
   since they already just call `mediator.Send(...)`.
4. Replace `Auth/ToolAuthorization.cs`'s JWT setup with a project reference to `Shared.Auth` and
   reuse its Auth0 validation + Redis-backed revocation directly instead of the standalone config
   here.
5. Replace the in-memory `PendingPayouts` dictionary in the real `ClaimsService.Application`
   handler with a Postgres-backed table (or Redis with a TTL) — in-memory state doesn't survive a
   pod restart or work across the `replicas: 2` in `k8s/deployment.yaml`.

## Design notes worth reading before adding a new tool

- **Read-only tools** (`ReadOnlyTools.cs`) need no special handling — the agent can call them any
  number of times, in any order, with no side-effect risk.
- **Idempotent write tools** (`IdempotentWriteTools.cs`) are safe for the agent to retry because
  idempotency is enforced at the *handler* level, keyed on a natural business key (`orderId` +
  `sku`). This is a property of the handler, not the tool wrapper — if you add a new write tool,
  the idempotency guarantee has to be built into the command handler it calls, not bolted onto the
  tool method.
- **Confirm-gated tools** (`ConfirmGatedTools.cs`) exist for anything that isn't cleanly
  idempotent-by-key — payouts, deletes, anything where "the agent called it twice" is
  unacceptable regardless of key matching. The propose step never executes the effect; only
  `ConfirmPendingAction` does, and it's gated behind the narrowest scope in the system
  (`aiops:tools:confirm`), which in a real deployment should be granted to a human-approval
  service account, not to whatever credential the agent itself runs as.
- Every tool returns **structured JSON, including on failure** (`ToolExecutionGuard`) — never an
  unhandled exception or a raw stack trace. Tool output becomes untrusted input the model reasons
  over next; keep it minimal and structured.
- Tool descriptions are prompt engineering, not documentation. If the agent picks the wrong tool
  or passes bad arguments, the fix is almost always sharpening the `[Description]` text, not
  changing the method signature.

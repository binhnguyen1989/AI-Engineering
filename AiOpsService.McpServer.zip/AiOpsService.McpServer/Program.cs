using AiOpsService.McpServer.Auth;
using MediatR;
using Prometheus;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// --- Logging ---------------------------------------------------------------
builder.Host.UseSerilog((ctx, cfg) => cfg
    .ReadFrom.Configuration(ctx.Configuration)
    .Enrich.FromLogContext()
    .WriteTo.Console());

// --- MediatR -----------------------------------------------------------
// In the real solution, this scans OrderService.Application, InventoryService.Application,
// and ClaimsService.Application assemblies instead of just this project's Contracts/ folder.
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(Program).Assembly));

// --- Auth ----------------------------------------------------------------
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<Auth.ToolScopeGuard>();
builder.Services.AddAiOpsToolAuth(builder.Configuration);

// --- MCP server ------------------------------------------------------------
builder.Services
    .AddMcpServer()
    .WithHttpTransport()
    .WithToolsFromAssembly();

var app = builder.Build();

app.UseAuthentication();
app.UseAuthorization();

app.UseHttpMetrics(); // request duration/count histograms, matches existing Prometheus scrape config
app.MapMetrics();     // exposes /metrics

app.MapMcp("/mcp")
    .RequireAuthorization(ToolAuthorization.ReadOnlyPolicy);
    // NOTE: this gates "can call the MCP endpoint at all" on the broadest (read) scope.
    // Per-tool enforcement for write/confirm-scoped tools happens inside the tool methods
    // themselves via ToolScopeGuard — see ConfirmGatedTools.cs. Endpoint-level auth alone is
    // not sufficient once tools have different privilege levels behind one route.

app.MapGet("/health/live", () => Results.Ok(new { status = "live" }));
app.MapGet("/health/ready", () => Results.Ok(new { status = "ready" }));

app.Run();

// Exposes Program for WebApplicationFactory<Program> in the integration test project.
public partial class Program;

# Microservices Platform

A .NET microservices platform with dual messaging (Kafka for events,
RabbitMQ for work queues), Keycloak-based auth, a YARP API gateway, and a
full observability stack (Prometheus/Grafana, Loki/Promtail, Tempo/Jaeger).

## Quickstart

```powershell
# Bring up everything (dev mode: hot reload, all ports exposed)
./scripts/start.ps1 -Env dev

# Apply EF Core migrations once services have DbContexts
./scripts/migrate.ps1

# Load demo data
./scripts/seed.ps1

# Stop (keeps volumes/data)
./scripts/stop.ps1

# Full teardown, including volumes
./scripts/clean.ps1
```

Or with plain `docker compose`:
```bash
docker compose \
  --env-file .env --env-file .env.development \
  -f docker/compose/docker-compose.yml \
  -f docker/compose/docker-compose.dev.yml \
  up -d --build
```

## Architecture

```
                        ┌─────────┐
        client ───────► │  nginx  │  (TLS termination, edge LB)
                        └────┬────┘
                             ▼
                       ┌───────────┐
                       │  Gateway  │  (YARP + JWT auth)
                       └─────┬─────┘
        ┌───────┬───────┬───┴────┬─────────┬──────────────┐
        ▼       ▼       ▼        ▼         ▼              ▼
    Identity Product  Order  Inventory  Customer      Notification
        │       │       │        │         │              │
        └───────┴───┬───┴────────┴─────────┘              │
                     ▼                                     ▼
              Postgres (1 schema/svc)              Kafka + RabbitMQ
                     │
                Redis (cache/session)
```

Auth (Keycloak), service discovery (Consul), and secrets (Vault) sit
alongside as shared infrastructure. Observability (Prometheus, Grafana, Loki,
Tempo/Jaeger, OTel Collector) scrapes/receives from every service uniformly.

## Service ports (dev)

| Service              | URL                          |
|----------------------|-------------------------------|
| Gateway (via nginx)   | http://localhost:80           |
| Gateway (direct)      | http://localhost:5000          |
| Keycloak              | http://localhost:8080          |
| Grafana                | http://localhost:3000          |
| Prometheus             | http://localhost:9090          |
| Kafka UI               | http://localhost:8082          |
| RabbitMQ management    | http://localhost:15672         |
| Jaeger UI               | http://localhost:16686         |
| MinIO console           | http://localhost:9001          |
| Kibana                  | http://localhost:5601          |
| Consul UI                | http://localhost:8500          |
| Vault UI                  | http://localhost:8200          |

## Repo layout

- `docker/compose/` — one Compose file per concern, assembled via `include` in `docker-compose.yml`; `docker-compose.dev.yml` / `.prod.yml` are overrides.
- `docker/<component>/` — config files mounted into each container.
- `services/` — one folder per .NET service. `Gateway/` is fully scaffolded; see `services/README.md` to replicate the pattern for the rest.
- `scripts/` — PowerShell helpers for start/stop/clean/migrate/seed.

## Notes / things to decide as you build this out

- **Postgres exporter**: `prometheus.yml` points at `postgres-primary:5432` directly, but Postgres doesn't expose Prometheus metrics natively — add `postgres_exporter` (and `redis_exporter`, and Kafka's JMX exporter) as sidecars before relying on those scrape targets.
- **Secrets**: `.env.development` has dev-only defaults checked in; `.env.production` is a placeholder — wire real values through Vault or your CI/CD secret store, never commit them.
- **TLS**: `nginx.conf` only listens on 80 right now; add a cert mount + `listen 443 ssl` block before this goes anywhere near production traffic.
- **Kafka topic creation**: `docker/kafka/topics/topics.yml` is declarative documentation only — nothing currently applies it. Wire it into an init container or a CI step if you want topics created automatically.

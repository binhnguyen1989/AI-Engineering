path "secret/data/services/*" {
  capabilities = ["read", "list"]
}

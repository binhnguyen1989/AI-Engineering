datacenter = "dc1"
data_dir   = "/consul/data"
log_level  = "INFO"
server     = true
bootstrap_expect = 1

ui_config {
  enabled = true
}

connect {
  enabled = true
}

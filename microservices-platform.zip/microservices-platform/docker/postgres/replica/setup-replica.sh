#!/bin/bash
set -e

# Only run if the data directory is empty (first boot)
if [ -z "$(ls -A "$PGDATA" 2>/dev/null)" ]; then
  echo "Bootstrapping replica via pg_basebackup from postgres-primary..."
  pg_basebackup -h postgres-primary -D "$PGDATA" -U replicator -Fp -Xs -P -R
  chmod 0700 "$PGDATA"
fi

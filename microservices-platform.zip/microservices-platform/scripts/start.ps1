param(
    [ValidateSet("dev", "prod")]
    [string]$Env = "dev"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$composeDir = Join-Path $root "docker/compose"

$envFile = if ($Env -eq "prod") { ".env.production" } else { ".env.development" }
$overrideFile = if ($Env -eq "prod") { "docker-compose.prod.yml" } else { "docker-compose.dev.yml" }

Write-Host "Starting platform in '$Env' mode..." -ForegroundColor Cyan

docker compose `
    --env-file (Join-Path $root ".env") `
    --env-file (Join-Path $root $envFile) `
    -f (Join-Path $composeDir "docker-compose.yml") `
    -f (Join-Path $composeDir $overrideFile) `
    up -d --build

Write-Host "Stack is up. Try:" -ForegroundColor Green
Write-Host "  Gateway:    http://localhost:5000"
Write-Host "  Grafana:    http://localhost:3000"
Write-Host "  Kafka UI:   http://localhost:8082"
Write-Host "  Keycloak:   http://localhost:8080"
Write-Host "  RabbitMQ:   http://localhost:15672"
Write-Host "  MinIO:      http://localhost:9001"

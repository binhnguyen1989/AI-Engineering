param(
    [switch]$Force
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$composeDir = Join-Path $root "docker/compose"

if (-not $Force) {
    $confirm = Read-Host "This will remove all containers AND volumes (data loss). Type 'yes' to continue"
    if ($confirm -ne "yes") {
        Write-Host "Aborted." -ForegroundColor Yellow
        exit 0
    }
}

Write-Host "Removing containers, networks, and volumes..." -ForegroundColor Red

docker compose `
    -f (Join-Path $composeDir "docker-compose.yml") `
    down -v --remove-orphans

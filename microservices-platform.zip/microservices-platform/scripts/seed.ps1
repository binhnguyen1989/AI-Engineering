param(
    [string]$GatewayUrl = "http://localhost:5000"
)

$ErrorActionPreference = "Stop"

Write-Host "Seeding demo data via $GatewayUrl ..." -ForegroundColor Cyan

# NOTE: this assumes the Identity/Product/Customer services expose the routes
# below once scaffolded. Adjust paths/payloads as those services take shape.

$products = @(
    @{ sku = "SKU-1001"; name = "Wireless Mouse"; price = 24.99 },
    @{ sku = "SKU-1002"; name = "Mechanical Keyboard"; price = 89.99 },
    @{ sku = "SKU-1003"; name = "USB-C Hub"; price = 34.50 }
)

foreach ($p in $products) {
    try {
        Invoke-RestMethod -Method Post `
            -Uri "$GatewayUrl/api/products" `
            -ContentType "application/json" `
            -Body ($p | ConvertTo-Json)
        Write-Host "  Seeded product $($p.sku)" -ForegroundColor Green
    } catch {
        Write-Host "  Failed to seed $($p.sku): $($_.Exception.Message)" -ForegroundColor Red
    }
}

$customers = @(
    @{ email = "alice@example.com"; name = "Alice Nguyen" },
    @{ email = "bob@example.com"; name = "Bob Tran" }
)

foreach ($c in $customers) {
    try {
        Invoke-RestMethod -Method Post `
            -Uri "$GatewayUrl/api/customers" `
            -ContentType "application/json" `
            -Body ($c | ConvertTo-Json)
        Write-Host "  Seeded customer $($c.email)" -ForegroundColor Green
    } catch {
        Write-Host "  Failed to seed $($c.email): $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host "Seeding complete." -ForegroundColor Green

param(
    [ValidateSet("dev", "prod")]
    [string]$Env = "dev"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$composeDir = Join-Path $root "docker/compose"
$overrideFile = if ($Env -eq "prod") { "docker-compose.prod.yml" } else { "docker-compose.dev.yml" }

Write-Host "Stopping platform ($Env)..." -ForegroundColor Yellow

docker compose `
    -f (Join-Path $composeDir "docker-compose.yml") `
    -f (Join-Path $composeDir $overrideFile) `
    stop

param(
    [string[]]$Services = @("Identity", "Product", "Order", "Inventory", "Customer", "Notification")
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot

foreach ($svc in $Services) {
    $csprojDir = Join-Path $root "services/$svc"

    if (-not (Test-Path $csprojDir)) {
        Write-Host "Skipping $svc (no project found at $csprojDir)" -ForegroundColor DarkYellow
        continue
    }

    Write-Host "Applying EF Core migrations for $svc..." -ForegroundColor Cyan
    Push-Location $csprojDir
    try {
        dotnet ef database update --project . --startup-project .
    }
    finally {
        Pop-Location
    }
}

Write-Host "Migrations complete." -ForegroundColor Green

using Microsoft.AspNetCore.Authentication.JwtBearer;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;

var builder = WebApplication.CreateBuilder(args);

// --- Configuration ---------------------------------------------------------
// appsettings.Routes.json holds the YARP route/cluster definitions and is
// mounted separately in docker-compose so routes can change without a rebuild.
builder.Configuration.AddJsonFile("appsettings.Routes.json", optional: true, reloadOnChange: true);

var authority = builder.Configuration["Auth:Authority"] ?? "http://keycloak:8080/realms/platform";

// --- Services ---------------------------------------------------------------
builder.Services.AddReverseProxy()
    .LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"));

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = authority;
        options.RequireHttpsMetadata = false;
        options.Audience = "gateway";
    });

builder.Services.AddAuthorization();

builder.Services.AddOpenTelemetry()
    .ConfigureResource(r => r.AddService("gateway"))
    .WithTracing(t => t
        .AddAspNetCoreInstrumentation()
        .AddHttpClientInstrumentation()
        .AddOtlpExporter(o => o.Endpoint = new Uri(
            builder.Configuration["Otel:Endpoint"] ?? "http://otel-collector:4317")))
    .WithMetrics(m => m
        .AddAspNetCoreInstrumentation()
        .AddOtlpExporter());

builder.Services.AddHealthChecks();

var app = builder.Build();

// --- Middleware pipeline -----------------------------------------------------
app.UseHttpMetrics();               // prometheus-net request metrics
app.UseAuthentication();
app.UseAuthorization();

app.MapHealthChecks("/health");
app.MapMetrics("/metrics");         // prometheus-net scrape endpoint
app.MapReverseProxy();

app.Run();

# Services

`Gateway` is fully scaffolded and is the template for the rest. Each of the
other services (`Identity`, `Product`, `Order`, `Inventory`, `Customer`,
`Notification`, `Worker`) should follow the same shape:

```
services/<Name>/
├── <Name>.csproj
├── Program.cs
├── appsettings.json
├── Dockerfile
├── Endpoints/           # minimal-API endpoint groups or Controllers/
├── Domain/               # entities, value objects
├── Infrastructure/       # EF Core DbContext, repositories, messaging
└── Application/          # use cases / handlers (MediatR or hand-rolled)
```

**Conventions carried over from Gateway:**

- .NET 9, minimal hosting model (`WebApplication.CreateBuilder`).
- `/health` (health checks) and `/metrics` (prometheus-net) exposed on every service — `docker/prometheus/prometheus.yml` already scrapes these hostnames.
- OpenTelemetry wired to `otel-collector:4317` for traces/metrics; logs go to stdout and are picked up by Promtail.
- Each service owns one Postgres **schema** (see `docker/postgres/init/01-schemas.sql`), not a separate database — keeps local dev to a single Postgres container.
- Multi-stage Alpine Dockerfile identical in structure to Gateway's, just swapping the project name.
- Config split between `appsettings.json` (safe defaults, committed) and environment variables from `.env.development` / `.env.production` (secrets, not committed).

**Messaging:**
- Domain events (`order.created`, `inventory.reserved`, etc.) go through Kafka — topics are declared in `docker/kafka/topics/topics.yml`.
- Command/task-style work queues (e.g. dispatching a notification job) go through RabbitMQ — see `docker/rabbitmq/definitions.json` for pre-provisioned queues.

**To scaffold a new service quickly:**
```powershell
cd services
dotnet new webapi -n Product -o Product
# then copy over the OpenTelemetry/health/metrics wiring from Gateway/Program.cs
```

Add its route/cluster to `docker/yarp/appsettings.json` and a service block to
`docker/compose/docker-compose.gateway.yml` (or a new
`docker-compose.services.yml` once there are several — keeping one file per
service in the main compose stack starts to get noisy after 3–4).
